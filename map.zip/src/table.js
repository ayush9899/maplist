// import * as React from 'react';
// import Box from '@mui/material/Box';
// import {
//   DataGrid,
//   GridToolbarQuickFilter,
//   GridLinkOperator,
// } from '@mui/x-data-grid';
// //import { useDemoData } from '@mui/x-data-grid-generator';

// function QuickSearchToolbar() {
//   return (
//     <Box
//       sx={{
//         p: 0.5,
//         pb: 0,
//       }}
//     >
//       <GridToolbarQuickFilter
//         quickFilterParser={(searchInput) =>
//           searchInput
//             .split(',')
//             .map((value) => value.trim())
//             .filter((value) => value !== '')
//         }
//       />
//     </Box>
//   );
// }

// const VISIBLE_FIELDS = ['name', 'rating', 'country', 'dateCreated', 'isAdmin'];

// export default function QuickFilteringCustomizedGrid() {
//   const { data } = useDemoData({
//     dataSet: 'Employee',
//     visibleFields: VISIBLE_FIELDS,
//     rowLength: 100,
//   });

//   // Otherwise filter will be applied on fields such as the hidden column id
//   const columns = React.useMemo(
//     () => data.columns.filter((column) => VISIBLE_FIELDS.includes(column.field)),
//     [data.columns],
//   );

//   return (
//     <Box sx={{ height: 400, width: 1 }}>
//       <DataGrid
//         {...data}
//         columns={columns}
//         initialState={{
//           filter: {
//             filterModel: {
//               items: [],
//               quickFilterLogicOperator: GridLinkOperator.Or,
//             },
//           },
//         }}
//         components={{ Toolbar: QuickSearchToolbar }}
//       />
//     </Box>
//   );
// }